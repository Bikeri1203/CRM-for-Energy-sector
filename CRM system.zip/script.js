    var unitsInput = document.getElementById("units");
    var perAmountInput = document.getElementById("peramount");
    var tAmountInput = document.getElementById("tamount");
    var cAmountInput = document.getElementById("camount");
    var aAmountInput = document.getElementById("Aamount");

    unitsInput.addEventListener("input", calculateTotal);
    perAmountInput.addEventListener("input", calculateTotal);
    cAmountInput.addEventListener("input", calculateAccountAmount);

    tAmountInput.addEventListener("focus", calculateTotal);
    aAmountInput.addEventListener("focus", calculateAccountAmount);

    function calculateTotal() {
        var unitsValue = parseFloat(unitsInput.value);
        var perAmountValue = parseFloat(perAmountInput.value);
        var totalValue = unitsValue * perAmountValue;
        tAmountInput.value = isNaN(totalValue) ? "" : totalValue.toFixed(2); 
        calculateAccountAmount();
    }

    function calculateAccountAmount() {
        var totalAmountValue = parseFloat(tAmountInput.value);
        var additionalChargesValue = parseFloat(cAmountInput.value);
        var accountAmountValue = totalAmountValue + additionalChargesValue;
        aAmountInput.value = isNaN(accountAmountValue) ? "" : accountAmountValue.toFixed(2);
    }

